# CSC14003 - Introduction to Artificial Intelligence - Lab01 - Searching

To run the code, you need to have Python 3 installed on your machine. You can download Python 3 from [here](https://www.python.org/downloads/).

To run the code, you can use the following command (at `src` directory):

```bash

python main.py

```

Test cases are available in the `test` directory. You can change the test cases in the `main.py` file, on very first line of `main` function. (at `dir_path` variable)

For more information, please refer to the [Lab01 - Searching](https://drive.google.com/drive/folders/1BBMQ5vnBUdrahAtvJQBzBgJtfbGtd_fW?usp=drive_link)
